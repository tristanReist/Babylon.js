var createScene = function () {

    // This creates a basic Babylon Scene object (non-mesh)
    var scene = new BABYLON.Scene(engine);
    // This creates and positions a free camera (non-mesh)
    var camera = new BABYLON.UniversalCamera("camera1", new BABYLON.Vector3(10, 100, -10), scene);
    camera.attachControl(canvas, true);  


    BABYLON.SceneLoader.ImportMesh("", "./kaza/", "fileName.gltf", scene, function (meshes) {     

        for (let light of scene.lights){
            light.dispose();
        }
        
       // let textureStr = "./testKaza.png";
        camera.speed = 20;
        let boxProbes = [];

        for (let mesh of meshes) {
            if (mesh.name != "ground" && mesh.name != "earth" && mesh.name != "skybox" && mesh.name != "avatar" && mesh.name != "__root__"){
                boxProbes.push(mesh);
                mesh.material = mesh.material.clone();
            }      
        }

        let dico = new BABYLON.MeshDictionary(boxProbes, scene);
        console.log(dico);


        // Add mesh for light créer un ground  10 10 Ajouter dans nouveau tableau

        let lightSource = BABYLON.MeshBuilder.CreatePlane("lightSource", {width : 100, height : 100}, scene);
        lightSource.translate(new BABYLON.Vector3(-350, 230, 140 ), 1.);
        // lightSource.translate(new BABYLON.Vector3(10,100, -10 ), 1.);

        lightSource.rotate(BABYLON.Axis.Y, BABYLON.Tools.ToRadians(-90));
        lightSource.rotate(BABYLON.Axis.X, BABYLON.Tools.ToRadians(-90));

        let lightSourceMaterial = new BABYLON.StandardMaterial("whiteTexture", scene);
        lightSource.material = lightSourceMaterial;


        let renderedMeshes = [];
        for (let mesh of boxProbes) {
            renderedMeshes.push(mesh);
        }
        renderedMeshes.push(lightSource);

        let pr = new BABYLON.RadiosityRenderer(scene, renderedMeshes, { bias: 0.000002, normalBias: 0.000002 });
 
  

        const mapper = new BABYLON.UvMapper();  


        for (let mesh of renderedMeshes){
            let worldToUVRatio = mapper.map([mesh], 0);

            mesh.initForRadiosity();
            mesh.radiosityInfo.texelWorldSize = 1 / ( worldToUVRatio * mesh.radiosityInfo.lightmapSize.width);   
            
            // mesh.radiosityInfo.lightmapSize = {width : 256, height : 256};
            //radiosityInfo.lightmapSize() dans meshDictionary
            //Si pb (long) baisser la taille de la lightmap


        }


        lightSource.radiosityInfo.lightmapSize = {width : 16, height : 16};
        lightSource.radiosityInfo.color = new BABYLON.Vector3(5000., 5000., 5000.);


        pr.createMaps();


        var observer = scene.onAfterRenderTargetsRenderObservable.add(() => {
            if (!pr.isReady()) {
                return;
            }
            pr.gatherDirectLightOnly();
            scene.onAfterRenderTargetsRenderObservable.remove(observer);


            console.log("end compute radiosity");

            for (let mesh of dico.keys()){
                let value = dico.getValue(mesh);
                if (value != null) {
                    value.directLightmap = mesh.getRadiosityTexture();
                }

            }
            lightSourceMaterial.emissiveTexture = lightSource.getRadiosityTexture();
            lightSourceMaterial.backFaceCulling = false;

            dico.initIrradianceTexture();

            var volume = new BABYLON.UniformVolume(boxProbes, scene, dico, 16, 6, 3, 4, 2);
            volume.render();
    
             let finsihPromise = new Promise((resolve, reject) => {
                 let interval = setInterval(() => {
                     if ( ! volume.irradiance.finish ) {
                             return ;
                         }                
                     clearInterval(interval);
                     resolve();
                 }, 200);
             });
    
             finsihPromise.then(function (){
                                //  Additionner les deux couleurs pour faire une vrai texture
                dico.renderSumOfBoth();

                for (let mesh of dico.keys()) {
                    let value = dico.getValue(mesh);  
                    if (value != null) {
                        // mesh.material.disableLighting = true;
                        // mesh.material.albedoColor.r **= 1.9; // gamma transform
                        // mesh.material.albedoColor.g **= 1.9; // gamma transform
                        // mesh.material.albedoColor.b **= 1.9; // gamma transform
                        // mesh.material.ambientTextureStrength = 3;
                        value.sumOfBoth.coordinatesIndex = 1;
                        mesh.material.lightmapTexture =  value.sumOfBoth;

                        // value.irradianceLightmap.coordinatesIndex = 1;
                        // mesh.material.lightmapTexture =  value.irradianceLightmap;

                        // value.directLightmap.coordinatesIndex = 1;
                        // mesh.material.lightmapTexture =  value.directLightmap;

                        // console.log(mesh.material.albedoTexture);
                        // console.log(mesh.material.albedoColor);
                        // mesh.material.useLightmapAsShadowmap = true;
                    }
                }
                console.log(lightSource);    
            }); 
/*
              
        let customMesh = new BABYLON.Mesh("custom", this._scene);
        let position = [-1, -1, 0, 1, -1, 0, 1, 1, 0, -1, -1, 0, 1, 1, 0, -1, 1, 0];
        let indices = [0, 1, 2, 3, 4, 5];
        let vertexData = new BABYLON.VertexData();
        customMesh.visibility = 0;
        vertexData.positions = position;
        vertexData.indices = indices;

        vertexData.applyToMesh(customMesh);

        var sha = new BABYLON.ShaderMaterial("uvShader", scene, "./../../src/Shaders/irradianceVolumeCubeMapInLine", {
            attributes: ["position"],
            uniforms: []
        });
        sha.setTextureArray("cubeMapArray", [volume.irradiance.probeList[19].tempBounce]);
        sha.setInt("resolution", 16);
        sha.setInt("numberCube", 1);
        sha.backFaceCulling = false;
        customMesh.material = sha;

        let cubeMap = new BABYLON.RenderTargetTexture("tacé", {width : 16 * 6 * 4, height : 16 * 4}, this._scene);
        scene.customRenderTargets.push(cubeMap);
        cubeMap.renderList = [customMesh];

        let view2 = new ColorTextureView(canvas, new BABYLON.Vector2(0, 0), new BABYLON.Vector2(16 * 6 * 4, 16 * 4),cubeMap._texture);

        // view.render();
        let viewManager = new ViewManager(scene.getEngine());
        viewManager.AddView(view2);
*/
        });






    /*
        const uvs = [];
        const indices = [];
        //for (const mesh of boxProbes) {
        for (const mesh of dico.values()[4].meshes){
            uvs.push(mesh.getVerticesData("uv2"));
            indices.push(mesh.getIndices());
            
        }

        mapper.debugUvs(new BABYLON.Vector2(0, 0), new BABYLON.Vector2(500, 500),  uvs, indices);
    
    
    let view = new ColorTextureView(canvas, new BABYLON.Vector2(0, 0), new BABYLON.Vector2(500, 500),dico.values()[4].irradianceLightmap._texture);
    //let view = new ColorTextureView(canvas, new BABYLON.Vector2(0, 0), new BABYLON.Vector2(300, 300),texture._texture);
    let viewManager = new ViewManager(scene.getEngine());
    viewManager.AddView(view);    
  */

    

});

    return scene;

};