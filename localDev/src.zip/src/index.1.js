var createScene = function () {

    // This creates a basic Babylon Scene object (non-mesh)
    var scene = new BABYLON.Scene(engine);
    var light = new BABYLON.DirectionalLight("light1", new BABYLON.Vector3(-1, -1, -1), scene);
    // This creates and positions a free camera (non-mesh)
    var camera = new BABYLON.UniversalCamera("camera1", new BABYLON.Vector3(0, 0, -10), scene);
    // camera.cameraDirection = new BABYLON.Vector3(-1, 0, 0);
    camera.attachControl(canvas, true);  

    var box = new BABYLON.MeshBuilder.CreateBox("skyBox", {size : 40}, scene);
    
    var shaderMaterial = new BABYLON.ShaderMaterial("uvShader", scene, "./../../src/Shaders/showAlbeCube", {
        attributes: ["position"],
        uniforms: ["worldViewProjection"]
    });
    var txtString = "../../Playground/textures/skybox2";
    var texture = new BABYLON.CubeTexture(txtString, scene);
    shaderMaterial.setTexture("albedo", texture)
    shaderMaterial.backFaceCulling = false;
    box.material = shaderMaterial;

    var centralPosition = new BABYLON.Vector3(0, 0, 0);

    var resolution = 16;

    var probe = new BABYLON.Probe(centralPosition, scene, txtString, true);
    probe.setVisibility(1);

    var volume = new BABYLON.Volume([box], scene, resolution, [probe]);
    volume.render();
    

    return scene;

};