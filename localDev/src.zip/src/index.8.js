var createScene = function () {

    // This creates a basic Babylon Scene object (non-mesh)
    var scene = new BABYLON.Scene(engine);
    var light = new BABYLON.DirectionalLight("light1", new BABYLON.Vector3(-1, -1, -1), scene);
    // This creates and positions a free camera (non-mesh)
    var camera = new BABYLON.UniversalCamera("camera1", new BABYLON.Vector3(0, 0, -10), scene);
    // camera.cameraDirection = new BABYLON.Vector3(-1, 0, 0);
    camera.attachControl(canvas, true);  


    BABYLON.SceneLoader.ImportMesh("", "./", "shadowMappingScene.gltf", scene, function (meshes) {     
        //Ajout d'un shader permettant de vérifier si les résultats qui sont nouveaux sont corrects
        
        
        var shaderMaterial = new BABYLON.ShaderMaterial("uvShader", scene, "./../../src/Shaders/showAlbe", {
            attributes: ["position", "uv"],
            uniforms: ["worldViewProjection"]
        });
        var textureStr = "./test.png"
        var textureStrBis = "./test.png"
        var texture = new BABYLON.Texture(textureStrBis, scene);


        for (let mesh of meshes){
            if (mesh.metadata != null){
                mesh.material = shaderMaterial;
            }
        }
    
        var volume = new BABYLON.UniformVolume(meshes, scene, textureStr, 128, 1, 1, 1, 3);
        volume.render();
        shaderMaterial.setTexture("albedo", volume.irradiance.irradianceLightmap);




        let customMesh = new BABYLON.Mesh("custom", this._scene);
        let position = [-1, -1, 0, 1, -1, 0, 1, 1, 0, -1, -1, 0, 1, 1, 0, -1, 1, 0];
        let indices = [0, 1, 2, 3, 4, 5];
        let vertexData = new BABYLON.VertexData();
        customMesh.visibility = 0;
        vertexData.positions = position;
        vertexData.indices = indices;

        vertexData.applyToMesh(customMesh);

        var sha = new BABYLON.ShaderMaterial("uvShader", scene, "./../../src/Shaders/irradianceVolumeCubeMapInLine", {
            attributes: ["position"],
            uniforms: []
        });
        sha.setTextureArray("cubeMapArray", [volume.irradiance.probeList[0].tempBounce]);
        sha.setInt("resolution", 128);
        sha.setInt("numberCube", 1);
        sha.backFaceCulling = false;
        customMesh.material = sha;

        let cubeMap = new BABYLON.RenderTargetTexture("tacé", {width : 128 * 6, height : 128}, this._scene);
        scene.customRenderTargets.push(cubeMap);
        cubeMap.renderList = [customMesh];



        let textureAlbedo = new BABYLON.RenderTargetTexture("texture", 512, this._scene);
         scene.customRenderTargets.push(textureAlbedo);
         textureAlbedo.renderList = this.meshes;
         textureAlbedo.activeCamera = camera;
         textureAlbedo.onBeforeRenderObservable.add(() => {
            shaderMaterial.setTexture("albedo", texture);
         });

         textureAlbedo.onAfterRenderObservable.add(() => {
            shaderMaterial.setTexture("albedo", volume.irradiance.irradianceLightmap);
         });


         let irradianceAlbedo = new BABYLON.RenderTargetTexture("texture", 512, this._scene);
         scene.customRenderTargets.push(irradianceAlbedo);
         irradianceAlbedo.renderList = this.meshes;
         irradianceAlbedo.activeCamera = camera;
         irradianceAlbedo.onBeforeRenderObservable.add(() => {
            shaderMaterial.setTexture("albedo", volume.irradiance.irradianceLightmap);
         });

         irradianceAlbedo.onAfterRenderObservable.add(() => {
            shaderMaterial.setTexture("albedo", volume.irradiance.irradianceLightmap);
         });


        let view = new ColorTextureView(canvas, new BABYLON.Vector2(0, 0), new BABYLON.Vector2(400, 200), textureAlbedo._texture);
        // let view2 = new ColorTextureView(canvas, new BABYLON.Vector2(0, 200), new BABYLON.Vector2(400, 200), irradianceAlbedo._texture);
        let view2 = new ColorTextureView(canvas, new BABYLON.Vector2(0, 200), new BABYLON.Vector2(600, 100),cubeMap._texture);

        // view.render();
        let viewManager = new ViewManager(scene.getEngine());
        viewManager.AddView(view);
        viewManager.AddView(view2);

    });

    return scene;

};