var createScene = function () {

    // This creates a basic Babylon Scene object (non-mesh)
    var scene = new BABYLON.Scene(engine);

    // This creates and positions a free camera (non-mesh)
    var camera = new BABYLON.UniversalCamera("camera1", new BABYLON.Vector3(10, 100, -10), scene);
    camera.attachControl(canvas, true);  


    BABYLON.SceneLoader.ImportMesh("", "./kaza/", "fileName.gltf", scene, function (meshes) {     
        //Ajout d'un shader permettant de vérifier si les résultats qui sont nouveaux sont corrects

       
        camera.speed = 20;
        let boxProbes = [];

        for (let mesh of meshes) {
            if (mesh.name != "ground" && mesh.name != "earth" && mesh.name != "skybox" && mesh.name != "avatar" && mesh.name != "__root__"){
                boxProbes.push(mesh)
                mesh.material = mesh.material.clone();
                // mesh.visibility = 0;
            } 
      
        }


        let dico = new BABYLON.MeshDictionary(boxProbes);
        console.log(dico);

        let  texture = new BABYLON.Texture("./blackSquare.png", scene);
        let textureCol = new BABYLON.Texture("./windowFlooring.png", scene);

        const mapper = new BABYLON.UvMapper();  

        for (let mesh of dico.keys()){
            mapper.map([mesh], 0);
            let value = dico.getValue(mesh);
            if (mesh.name == "flooring") {
                value.directLightmap = textureCol; 

            }
            else {
                value.directLightmap = textureCol;
            }
         
        }
        dico.initIrradianceTexture();



        var volume = new BABYLON.UniformVolume(boxProbes, scene, dico, 16, 6, 3, 4, 2);
        // volume.render();

  


         let finsihPromise = new Promise((resolve, reject) => {
             let interval = setInterval(() => {
                 if ( ! volume.irradiance.finish ) {
                         return ;
                     }                
                 clearInterval(interval);
                 resolve();
             }, 200);
         });

         finsihPromise.then(function (){
            for (let mesh of dico.keys()) {
                let value = dico.getValue(mesh);  
                if (value != null) {
                    value.irradianceLightmap.coordinatesIndex = 1;
                    // value.irradianceLightmap.invertY = true;
                    console.log(value.irradianceLightmap);
                    mesh.material.lightmapTexture =  value.irradianceLightmap;  
                    mesh.material.lightmapTexture.coordinatesIndex = 1;
                }
            }
         });
/*
    
        const uvs = [];
        const indices = [];
        
        let ind = 5;
        uvs.push(dico.keys()[ind].getVerticesData("uv2"));
        indices.push(dico.keys()[ind].getIndices());

        mapper.debugUvs(new BABYLON.Vector2(0, 0), new BABYLON.Vector2(500, 500),  uvs, indices);
     
        
        let view = new ColorTextureView(canvas, new BABYLON.Vector2(0, 0), new BABYLON.Vector2(500, 500),dico.values()[ind].irradianceLightmap._texture);
        //let view = new ColorTextureView(canvas, new BABYLON.Vector2(0, 0), new BABYLON.Vector2(300, 300),texture._texture);
        let viewManager = new ViewManager(scene.getEngine());
        viewManager.AddView(view);
  */
        /*

    let customMesh = new BABYLON.Mesh("custom", this._scene);
    let position = [-1, -1, 0, 1, -1, 0, 1, 1, 0, -1, -1, 0, 1, 1, 0, -1, 1, 0];
    let indices = [0, 1, 2, 3, 4, 5];
    let vertexData = new BABYLON.VertexData();
    customMesh.visibility = 0;
    vertexData.positions = position;
    vertexData.indices = indices;

    vertexData.applyToMesh(customMesh);

    var sha = new BABYLON.ShaderMaterial("uvShader", scene, "./../../src/Shaders/irradianceVolumeCubeMapInLine", {
        attributes: ["position"],
        uniforms: []
    });
    sha.setTextureArray("cubeMapArray", [volume.irradiance.probeList[19].tempBounce]);
    sha.setInt("resolution", 16);
    sha.setInt("numberCube", 1);
    sha.backFaceCulling = false;
    customMesh.material = sha;

    let cubeMap = new BABYLON.RenderTargetTexture("tacé", {width : 16 * 6 * 4, height : 16 * 4}, this._scene);
    scene.customRenderTargets.push(cubeMap);
    cubeMap.renderList = [customMesh];

    let view2 = new ColorTextureView(canvas, new BABYLON.Vector2(0, 0), new BABYLON.Vector2(16 * 6 * 4, 16 * 4),cubeMap._texture);

    // view.render();
    let viewManager = new ViewManager(scene.getEngine());
    viewManager.AddView(view2);
*/
    });

    return scene;

};