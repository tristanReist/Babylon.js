var createScene = function () {

    // This creates a basic Babylon Scene object (non-mesh)
    var scene = new BABYLON.Scene(engine);
    var light = new BABYLON.DirectionalLight("light1", new BABYLON.Vector3(-1, -1, -1), scene);
    // This creates and positions a free camera (non-mesh)
    var camera = new BABYLON.UniversalCamera("camera1", new BABYLON.Vector3(0, 0, -10), scene);
    // camera.cameraDirection = new BABYLON.Vector3(-1, 0, 0);
    camera.attachControl(canvas, true);  
    BABYLON.SceneLoader.ImportMesh("", "./", "shadowMappingScene.gltf", scene, function (meshes) {     

        var texture = new BABYLON.Texture("./../../Playground/textures/bloc.jpg", scene);
        
        let view = new View(canvas, new BABYLON.Vector2(0, 0),  new BABYLON.Vector2(100, 100), texture._texture);
        let viewManager = new ViewManager(scene);
        viewManager.AddView(view);

    });

    

    return scene;

};