var createScene = function () {

    // This creates a basic Babylon Scene object (non-mesh)
    var scene = new BABYLON.Scene(engine);
    var light = new BABYLON.DirectionalLight("light1", new BABYLON.Vector3(-1, -1, -1), scene);
    // This creates and positions a free camera (non-mesh)
    var camera = new BABYLON.UniversalCamera("camera1", new BABYLON.Vector3(0, 0, -10), scene);
    // camera.cameraDirection = new BABYLON.Vector3(-1, 0, 0);
    camera.attachControl(canvas, true);  


    BABYLON.SceneLoader.ImportMesh("", "./", "shadowMappingScene.gltf", scene, function (meshes) {     
        //Ajout d'un shader permettant de vérifier si les résultats qui sont nouveaux sont corrects
        
        
        var shaderMaterial = new BABYLON.ShaderMaterial("uvShader", scene, "./../../src/Shaders/showAlbe", {
            attributes: ["position", "uv"],
            uniforms: ["worldViewProjection"]
        });
        var textureStr = "./../../Playground/textures/bloc.jpg"
        var textureStrBis = "./../../Playground/textures/bloc.jpg"
        var texture = new BABYLON.Texture(textureStrBis, scene);


        for (let mesh of meshes){
            if (mesh.metadata != null){
                mesh.material = shaderMaterial;
            }
        }
    
        var volume = new BABYLON.UniformVolume(meshes, scene, textureStr, 16, 3, 2, 3);
        volume.render();
        shaderMaterial.setTexture("albedo", volume.irradiance.irradianceLightmap);
        
    });

    return scene;

};