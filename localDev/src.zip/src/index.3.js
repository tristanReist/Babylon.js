var createScene = function () {

    // This creates a basic Babylon Scene object (non-mesh)
    var scene = new BABYLON.Scene(engine);

    // This creates and positions a free camera (non-mesh)
    var camera = new BABYLON.UniversalCamera("camera1", new BABYLON.Vector3(10, 100, -10), scene);
    // camera.cameraDirection = new BABYLON.Vector3(-1, 0, 0);
    camera.attachControl(canvas, true);  


    BABYLON.SceneLoader.ImportMesh("", "./kaza2/", "untitled.gltf", scene, function (meshes) {     
        //Ajout d'un shader permettant de vérifier si les résultats qui sont nouveaux sont corrects
        let textAndAlbedoMaterial= new BABYLON.ShaderMaterial("completeShader", scene, "./../../src/Shaders/irradianceVolumeCompleteIllumination", {
            attributes : ["position", "uv"],
            uniforms : ["worldViewProjection"]
        })

        camera.speed = 20;
        let boxProbes = [];
        for (let mesh of meshes) {
            boxProbes.push(mesh);      
        }
        let textureStr = "./testKaza.png";
        var volume = new BABYLON.UniformVolume(boxProbes, scene, textureStr, 16, 6, 3, 4, 5);
        volume.render();



        for (let mesh of meshes) {
            if (mesh.material != null){
                mesh.material.ambientTexture = volume.irradiance.irradianceLightmap;
            }
        }
    });

    return scene;

};