window.guiInstance = new dat.GUI();

window.generateDebugFolder = function(object, panelName) {
    const propertiesName = window.getInterestingProperties(object);
    const folder = window.guiInstance.addFolder(panelName);
    folder.open();

    propertiesName.forEach(propertyName => {
        folder.add(object, propertyName);
    });

    return folder;
}

window.getInterestingProperties = function(object) {
    const propertiesRegex = /^[a-z]/;
    const propertiesName = [];

    propertiesName.push(
        ...Object.getOwnPropertyNames(object).filter(
            name =>
                propertiesRegex.test(name)
                && typeof object[name] !== "function"
                && typeof object[name] !== "object"
        )
    );
    propertiesName.push(
        ...Object.keys(Object.getPrototypeOf(object)).filter(
            key =>
                propertiesRegex.test(key)
                && typeof object[key] !== "function"
                && typeof object[key] !== "object"
        )
    );

    return propertiesName;
}
